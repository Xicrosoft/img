import React from "react";
import "./styles.css"

export default function About() {
    return (
        <div className="about">
            <h2>关于CyberChat</h2>
            <li>Developer: fffzlfk</li>
            <li>Email: fffzlfk@qq.com</li>
        </div>
    );
}